#include <stdio.h>
int main()
{
	int result = 0;
	int n = 0;
	for (int i = 500; i <= 600; i++)
	{
		for (int j = 2; j <= (i / j); j++) {

			if (!(i % j)) {


				break;
			}
		
			
		printf("%d\t\n", i);
		result = result + i;

		n++;
		break;
			//if (j > (i / j))


		}
	}
	printf("�ܺ��ǣ�%d,�����ǣ�%d\n ", result, n);

	return 0;
}


